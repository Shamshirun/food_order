<?php 
	define('DB_USERNAME','root');
	define('DB_PASSWORD','codeRuth@3910');
	define('DB_NAME','FCM');
	define('DB_HOST','localhost');

	//defined a new constant for firebase api key
	define('FIREBASE_API_KEY', 'AIzaSyA1UaVc3OpezwOFgp0dhdLFPGJe9oz7-eM');
?>
