<?php
print_r (phpinfo());
?>
