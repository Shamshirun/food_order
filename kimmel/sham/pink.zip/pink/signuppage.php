<!DOCTYPE html>
<html>
<body>

<?php include("navigation.html") ?>

<form action="signup.php" method="post" >

	<h1> New Customer </h1>
Please input your email address<br><input type="text" name="email"/><br><br>
Please input your password<br> <input type="text" name="password"/><br><br>

<input type="submit" name="signup" value="Sign up!">
</form>





	</body>
	</html>
