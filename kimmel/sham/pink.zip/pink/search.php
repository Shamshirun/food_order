<!DOCTYPE html>
<html>
<body>

<?php include("navigation.html") ?>





<form action="ordersearch.php" method="post" >
<h3> Order Search</h3>
<h5>Input your OrderID</h5>
OrderID<br><input type="text" name="OrderID"/><br><br>

<input type="submit" name="" value="Search order">
</form>



</body>
</html>
